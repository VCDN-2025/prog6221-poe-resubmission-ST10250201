﻿using System;

namespace CybersecurityGUI
{
    public class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? Reminder { get; set; }
        public bool Completed { get; set; }

        public override string ToString()
        {
            string reminderStr = Reminder.HasValue ? $" (Reminder: {Reminder.Value:g})" : "";
            string status = Completed ? "[Done] " : "";
            return $"{status}{Title}{reminderStr}";
        }
    }
}

/*
 * Title:        How to Build a Simple To‑Do List App in Console Application Using C#
 * Author:       Tahir Mahmood
 * Date:         19 October 2024
 * Availability: https://medium.com/@tahir185/how-to-build-a-simple-to-do-list-app-in-console-application-using-c-234172b084b0
 */
