﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using CybersecurityGUI;   

namespace CybersecurityChatbot
{
    public partial class Form1 : Form
    {
      
        private List<TaskItem> tasks = new List<TaskItem>();
        private List<string> activityLog = new List<string>();

        
        private int quizIndex = 0;
        private int quizScore = 0;
        private List<QuizQuestion> quizQuestions;

       
        private enum ConversationState
        {
            None,
            WaitingForReminderConfirmation,
            WaitingForReminderTime
        }
        private ConversationState currentState = ConversationState.None;
        private string pendingTaskDescription = null;

        public Form1()
        {
            InitializeComponent();

            
            InitializeQuiz();
        }

        
        private void btnSend_Click(object sender, EventArgs e)
        {
            string input = txtChatInput.Text.Trim();
            string inputLower = input.ToLower();
            txtChatHistory.AppendText($"You: {input}\n");
            txtChatInput.Clear();

            switch (currentState)
            {
                case ConversationState.None:
                    if (inputLower.StartsWith("add task -"))
                    {
                        // Extract and add the task immediately
                        pendingTaskDescription = input.Substring(10).Trim();
                        var newTask = new TaskItem
                        {
                            Title = pendingTaskDescription,
                            Description = pendingTaskDescription,
                            Completed = false
                        };
                        tasks.Add(newTask);
                        lstTasks.Items.Add(newTask);
                        Log($"Task added: {pendingTaskDescription}");

                        txtChatHistory.AppendText(
                            $"Bot: Task added with description \"{pendingTaskDescription}\". Would you like a reminder?\n");
                        currentState = ConversationState.WaitingForReminderConfirmation;
                    }
                    else if (inputLower.Contains("add task") || inputLower.Contains("remind"))
                    {
                        tabControl.SelectedTab = tabTasks;
                        txtChatHistory.AppendText("Bot: Switched you to the Task tab to add/manage tasks.\n");
                        Log("Switched to Task Assistant via NLP command.");
                    }
                    else if (inputLower.Contains("quiz"))
                    {
                        tabControl.SelectedTab = tabQuiz;
                        txtChatHistory.AppendText("Bot: Starting the cybersecurity quiz!\n");
                        Log("User started quiz via NLP command.");
                    }
                    else if (inputLower.Contains("log") || inputLower.Contains("what have you done"))
                    {
                        tabControl.SelectedTab = tabLog;
                        txtChatHistory.AppendText("Bot: Showing recent activity log.\n");
                        Log("User viewed activity log via NLP.");
                    }
                    else
                    {
                        // fallback responses
                        if (inputLower.Contains("worried") || inputLower.Contains("frustrated"))
                            txtChatHistory.AppendText("Bot: I understand how you feel. Cybersecurity can be tricky—I'm here to help!\n");
                        else if (inputLower.Contains("password"))
                            txtChatHistory.AppendText("Bot: Use strong, unique passwords and enable 2FA whenever you can.\n");
                        else if (inputLower.Contains("phishing"))
                            txtChatHistory.AppendText("Bot: Don’t click suspicious links. Always verify the sender’s address.\n");
                        else
                            txtChatHistory.AppendText("Bot: Sorry, I didn't catch that. Try asking about passwords, scams, or privacy.\n");
                    }
                    break;

                case ConversationState.WaitingForReminderConfirmation:
                    if (inputLower.StartsWith("yes"))
                    {
                        txtChatHistory.AppendText(
                            "Bot: When would you like me to remind you? e.g. \"in 3 days\" or \"in 2 hours\".\n");
                        currentState = ConversationState.WaitingForReminderTime;
                    }
                    else
                    {
                        txtChatHistory.AppendText("Bot: Okay, no reminder set.\n");
                        currentState = ConversationState.None;
                        pendingTaskDescription = null;
                    }
                    break;

                case ConversationState.WaitingForReminderTime:
                    DateTime? reminderTime = ParseReminderTime(inputLower);
                    if (reminderTime.HasValue)
                    {
                        var task = tasks.FindLast(t => t.Title == pendingTaskDescription);
                        if (task != null)
                        {
                            task.Reminder = reminderTime;
                            int idx = lstTasks.Items.IndexOf(task);
                            if (idx != -1)
                                lstTasks.Items[idx] = task;  // refresh display
                            Log($"Reminder set for '{task.Title}' at {reminderTime}");
                        }

                        TimeSpan diff = reminderTime.Value - DateTime.Now;
                        txtChatHistory.AppendText($"Bot: Got it! I'll remind you {FriendlyTimeSpan(diff)}.\n");

                        currentState = ConversationState.None;
                        pendingTaskDescription = null;
                    }
                    else
                    {
                        txtChatHistory.AppendText(
                            "Bot: Sorry, I didn't understand that. Try \"in 3 days\" or \"in 2 hours\".\n");
                    }
                    break;
            }
        }

        // === TASK ASSISTANT ===
        private void btnAddTask_Click(object sender, EventArgs e)
        {
            string title = txtTaskTitle.Text.Trim();
            string desc = txtTaskDesc.Text.Trim();
            DateTime? reminder = chkReminder.Checked ? (DateTime?)dtpReminder.Value : null;

            if (string.IsNullOrEmpty(title))
            {
                MessageBox.Show("Task title cannot be empty.", "Validation Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var task = new TaskItem
            {
                Title = title,
                Description = desc,
                Reminder = reminder,
                Completed = false
            };
            tasks.Add(task);
            lstTasks.Items.Add(task);
            Log($"Task added: {title}{(reminder.HasValue ? $" (Reminder: {reminder.Value:g})" : "")}");
            ClearTaskInputs();
        }

        private void btnDeleteTask_Click(object sender, EventArgs e)
        {
            if (lstTasks.SelectedItem is TaskItem task)
            {
                tasks.Remove(task);
                lstTasks.Items.Remove(task);
                Log($"Task deleted: {task.Title}");
            }
        }

        private void ClearTaskInputs()
        {
            txtTaskTitle.Clear();
            txtTaskDesc.Clear();
            chkReminder.Checked = false;
            dtpReminder.Value = DateTime.Now;
        }

        // === QUIZ ===
        private void InitializeQuiz()
        {
            quizQuestions = QuizQuestion.GetSampleQuestions();
            quizIndex = 0;
            quizScore = 0;
            lblFeedback.Text = "";
            ShowNextQuizQuestion();
        }

        private void ShowNextQuizQuestion()
        {
            if (quizIndex >= quizQuestions.Count)
            {
                lblQuiz.Text = $"Quiz Complete! You scored {quizScore} out of {quizQuestions.Count}.";
                Log($"Quiz completed. Score: {quizScore}/{quizQuestions.Count}");
                lstQuizOptions.Enabled = false;
                btnNextQuestion.Enabled = false;
                btnStartQuiz.Enabled = true;
                return;
            }

            var q = quizQuestions[quizIndex];
            lblQuiz.Text = q.Question;

            lstQuizOptions.Items.Clear();
            foreach (var opt in q.Options)
                lstQuizOptions.Items.Add(opt);

            lstQuizOptions.Enabled = true;
            btnNextQuestion.Enabled = true;
            btnStartQuiz.Enabled = false;
            lblFeedback.Text = "";
        }

        private void btnStartQuiz_Click(object sender, EventArgs e)
        {
            InitializeQuiz();
        }

        private void btnNextQuestion_Click(object sender, EventArgs e)
        {
            if (lstQuizOptions.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an answer before proceeding.", "No Answer Selected",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var selected = lstQuizOptions.SelectedItem.ToString();
            var q = quizQuestions[quizIndex];

            if (selected == q.Answer)
            {
                quizScore++;
                lblFeedback.ForeColor = System.Drawing.Color.Green;
                lblFeedback.Text = "Correct! " + q.Feedback;
            }
            else
            {
                lblFeedback.ForeColor = System.Drawing.Color.Red;
                lblFeedback.Text = "Incorrect. " + q.Feedback;
            }

            quizIndex++;
            ShowNextQuizQuestion();
        }

        // === ACTIVITY LOG ===
        private void Log(string message)
        {
            activityLog.Insert(0, $"[{DateTime.Now:HH:mm}] {message}");
            if (activityLog.Count > 10)
                activityLog.RemoveAt(activityLog.Count - 1);

            lstLog.Items.Clear();
            foreach (var entry in activityLog)
                lstLog.Items.Add(entry);
        }

       
        private DateTime? ParseReminderTime(string input)
        {
            if (!input.StartsWith("in "))
                return null;
            var parts = input.Substring(3).Split(' ');
            if (parts.Length != 2 || !int.TryParse(parts[0], out int val))
                return null;

            var now = DateTime.Now;
            if (parts[1].StartsWith("day")) return now.AddDays(val);
            if (parts[1].StartsWith("hour")) return now.AddHours(val);
            if (parts[1].StartsWith("minute")) return now.AddMinutes(val);
            return null;
        }

        private string FriendlyTimeSpan(TimeSpan span)
        {
            if (span.TotalDays >= 1) return $"in {Math.Round(span.TotalDays)} days";
            if (span.TotalHours >= 1) return $"in {Math.Round(span.TotalHours)} hours";
            if (span.TotalMinutes >= 1) return $"in {Math.Round(span.TotalMinutes)} minutes";
            return "soon";
        }
    }

   
    public class TaskItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public DateTime? Reminder { get; set; }
        public bool Completed { get; set; }

        public override string ToString()
        {
            return $"{Title}"
                 + (Reminder.HasValue ? $" (Reminder: {Reminder.Value:g})" : "")
                 + (Completed ? " [Done]" : "");
        }
    }

   
}
