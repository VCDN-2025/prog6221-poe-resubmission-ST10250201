﻿namespace CybersecurityChatbot
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtChatHistory = new System.Windows.Forms.TextBox();
            this.txtChatInput = new System.Windows.Forms.TextBox();
            this.btnSend = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabChat = new System.Windows.Forms.TabPage();
            this.tabTasks = new System.Windows.Forms.TabPage();
            this.lstTasks = new System.Windows.Forms.ListBox();
            this.btnAddTask = new System.Windows.Forms.Button();
            this.btnDeleteTask = new System.Windows.Forms.Button();
            this.txtTaskTitle = new System.Windows.Forms.TextBox();
            this.txtTaskDesc = new System.Windows.Forms.TextBox();
            this.chkReminder = new System.Windows.Forms.CheckBox();
            this.dtpReminder = new System.Windows.Forms.DateTimePicker();
            this.tabQuiz = new System.Windows.Forms.TabPage();
            this.lblQuiz = new System.Windows.Forms.Label();
            this.lstQuizOptions = new System.Windows.Forms.ListBox();
            this.btnStartQuiz = new System.Windows.Forms.Button();
            this.btnNextQuestion = new System.Windows.Forms.Button();
            this.lblFeedback = new System.Windows.Forms.Label();
            this.tabLog = new System.Windows.Forms.TabPage();
            this.lstLog = new System.Windows.Forms.ListBox();

            this.tabControl.SuspendLayout();
            this.tabChat.SuspendLayout();
            this.tabTasks.SuspendLayout();
            this.tabQuiz.SuspendLayout();
            this.tabLog.SuspendLayout();
            this.SuspendLayout();

            // === Common Styles ===
            this.BackColor = System.Drawing.Color.FromArgb(20, 20, 30);
            this.ForeColor = System.Drawing.Color.White;
            this.Font = new System.Drawing.Font("Segoe UI", 10);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;

            // === txtChatHistory ===
            this.txtChatHistory.Multiline = true;
            this.txtChatHistory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtChatHistory.Location = new System.Drawing.Point(10, 10);
            this.txtChatHistory.Size = new System.Drawing.Size(400, 200);
            this.txtChatHistory.ReadOnly = true;
            this.txtChatHistory.BackColor = System.Drawing.Color.FromArgb(30, 30, 40);
            this.txtChatHistory.ForeColor = System.Drawing.Color.White;

            // === txtChatInput ===
            this.txtChatInput.Location = new System.Drawing.Point(10, 220);
            this.txtChatInput.Size = new System.Drawing.Size(300, 25);
            this.txtChatInput.BackColor = System.Drawing.Color.FromArgb(30, 30, 40);
            this.txtChatInput.ForeColor = System.Drawing.Color.White;

            // === btnSend ===
            this.btnSend.Text = "Send";
            this.btnSend.Location = new System.Drawing.Point(320, 220);
            this.btnSend.Size = new System.Drawing.Size(90, 25);
            this.btnSend.BackColor = System.Drawing.Color.Teal;
            this.btnSend.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSend.ForeColor = System.Drawing.Color.White;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);

            // === tabChat ===
            this.tabChat.Controls.Add(this.txtChatHistory);
            this.tabChat.Controls.Add(this.txtChatInput);
            this.tabChat.Controls.Add(this.btnSend);
            this.tabChat.Text = "Chat";
            this.tabChat.UseVisualStyleBackColor = true;
            this.tabChat.BackColor = this.BackColor;
            this.tabChat.ForeColor = this.ForeColor;

            // === Task Tab ===
            this.lstTasks.Location = new System.Drawing.Point(10, 10);
            this.lstTasks.Size = new System.Drawing.Size(200, 150);
            this.lstTasks.BackColor = System.Drawing.Color.FromArgb(30, 30, 40);
            this.lstTasks.ForeColor = System.Drawing.Color.White;

            this.txtTaskTitle.Location = new System.Drawing.Point(220, 10);
            this.txtTaskTitle.Size = new System.Drawing.Size(200, 25);
            this.txtTaskTitle.BackColor = this.txtChatInput.BackColor;
            this.txtTaskTitle.ForeColor = this.txtChatInput.ForeColor;

            this.txtTaskDesc.Location = new System.Drawing.Point(220, 40);
            this.txtTaskDesc.Size = new System.Drawing.Size(200, 25);
            this.txtTaskDesc.BackColor = this.txtChatInput.BackColor;
            this.txtTaskDesc.ForeColor = this.txtChatInput.ForeColor;

            this.chkReminder.Text = "Set Reminder";
            this.chkReminder.Location = new System.Drawing.Point(220, 70);

            this.dtpReminder.Location = new System.Drawing.Point(220, 100);
            this.dtpReminder.Size = new System.Drawing.Size(200, 25);
            this.dtpReminder.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpReminder.CustomFormat = "MM/dd/yyyy hh:mm tt";

            this.btnAddTask.Text = "Add";
            this.btnAddTask.Location = new System.Drawing.Point(220, 130);
            this.btnAddTask.Click += new System.EventHandler(this.btnAddTask_Click);
            this.btnAddTask.BackColor = System.Drawing.Color.Teal;
            this.btnAddTask.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAddTask.ForeColor = System.Drawing.Color.White;

            this.btnDeleteTask.Text = "Delete";
            this.btnDeleteTask.Location = new System.Drawing.Point(300, 130);
            this.btnDeleteTask.Click += new System.EventHandler(this.btnDeleteTask_Click);
            this.btnDeleteTask.BackColor = System.Drawing.Color.IndianRed;
            this.btnDeleteTask.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteTask.ForeColor = System.Drawing.Color.White;

            this.tabTasks.Controls.Add(this.lstTasks);
            this.tabTasks.Controls.Add(this.txtTaskTitle);
            this.tabTasks.Controls.Add(this.txtTaskDesc);
            this.tabTasks.Controls.Add(this.chkReminder);
            this.tabTasks.Controls.Add(this.dtpReminder);
            this.tabTasks.Controls.Add(this.btnAddTask);
            this.tabTasks.Controls.Add(this.btnDeleteTask);
            this.tabTasks.Text = "Tasks";
            this.tabTasks.UseVisualStyleBackColor = true;
            this.tabTasks.BackColor = this.BackColor;
            this.tabTasks.ForeColor = this.ForeColor;

            // === Quiz Tab ===
            this.lblQuiz.Location = new System.Drawing.Point(10, 10);
            this.lblQuiz.Size = new System.Drawing.Size(400, 30);

            this.lstQuizOptions.Location = new System.Drawing.Point(10, 40);
            this.lstQuizOptions.Size = new System.Drawing.Size(300, 100);
            this.lstQuizOptions.BackColor = this.lstTasks.BackColor;
            this.lstQuizOptions.ForeColor = this.lstTasks.ForeColor;

            this.btnStartQuiz.Text = "Start Quiz";
            this.btnStartQuiz.Location = new System.Drawing.Point(320, 40);
            this.btnStartQuiz.Click += new System.EventHandler(this.btnStartQuiz_Click);
            this.btnStartQuiz.BackColor = System.Drawing.Color.Teal;
            this.btnStartQuiz.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStartQuiz.ForeColor = System.Drawing.Color.White;

            this.btnNextQuestion.Text = "Next";
            this.btnNextQuestion.Location = new System.Drawing.Point(320, 80);
            this.btnNextQuestion.Click += new System.EventHandler(this.btnNextQuestion_Click);
            this.btnNextQuestion.BackColor = System.Drawing.Color.Teal;
            this.btnNextQuestion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNextQuestion.ForeColor = System.Drawing.Color.White;

            this.lblFeedback.Location = new System.Drawing.Point(10, 150);
            this.lblFeedback.Size = new System.Drawing.Size(400, 30);

            this.tabQuiz.Controls.Add(this.lblQuiz);
            this.tabQuiz.Controls.Add(this.lstQuizOptions);
            this.tabQuiz.Controls.Add(this.btnStartQuiz);
            this.tabQuiz.Controls.Add(this.btnNextQuestion);
            this.tabQuiz.Controls.Add(this.lblFeedback);
            this.tabQuiz.Text = "Quiz";
            this.tabQuiz.UseVisualStyleBackColor = true;
            this.tabQuiz.BackColor = this.BackColor;
            this.tabQuiz.ForeColor = this.ForeColor;

            // === Log Tab ===
            this.lstLog.Location = new System.Drawing.Point(10, 10);
            this.lstLog.Size = new System.Drawing.Size(400, 200);
            this.lstLog.BackColor = this.lstTasks.BackColor;
            this.lstLog.ForeColor = this.lstTasks.ForeColor;

            this.tabLog.Controls.Add(this.lstLog);
            this.tabLog.Text = "Log";
            this.tabLog.UseVisualStyleBackColor = true;
            this.tabLog.BackColor = this.BackColor;
            this.tabLog.ForeColor = this.ForeColor;

            // === Tab Control ===
            this.tabControl.Controls.Add(this.tabChat);
            this.tabControl.Controls.Add(this.tabTasks);
            this.tabControl.Controls.Add(this.tabQuiz);
            this.tabControl.Controls.Add(this.tabLog);
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;

            // === Form1 ===
            this.ClientSize = new System.Drawing.Size(450, 300);
            this.Controls.Add(this.tabControl);
            this.Text = "Cybersecurity Assistant";

            this.tabControl.ResumeLayout(false);
            this.tabChat.ResumeLayout(false);
            this.tabChat.PerformLayout();
            this.tabTasks.ResumeLayout(false);
            this.tabTasks.PerformLayout();
            this.tabQuiz.ResumeLayout(false);
            this.tabLog.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TextBox txtChatHistory;
        private System.Windows.Forms.TextBox txtChatInput;
        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage tabChat;
        private System.Windows.Forms.TabPage tabTasks;
        private System.Windows.Forms.ListBox lstTasks;
        private System.Windows.Forms.Button btnAddTask;
        private System.Windows.Forms.Button btnDeleteTask;
        private System.Windows.Forms.TextBox txtTaskTitle;
        private System.Windows.Forms.TextBox txtTaskDesc;
        private System.Windows.Forms.CheckBox chkReminder;
        private System.Windows.Forms.DateTimePicker dtpReminder;
        private System.Windows.Forms.TabPage tabQuiz;
        private System.Windows.Forms.Label lblQuiz;
        private System.Windows.Forms.ListBox lstQuizOptions;
        private System.Windows.Forms.Button btnStartQuiz;
        private System.Windows.Forms.Button btnNextQuestion;
        private System.Windows.Forms.Label lblFeedback;
        private System.Windows.Forms.TabPage tabLog;
        private System.Windows.Forms.ListBox lstLog;
    }
}

