﻿using System.Collections.Generic;

namespace CybersecurityGUI
{
    public class QuizQuestion
    {
        public string Question { get; set; }
        public List<string> Options { get; set; }
        public string Answer { get; set; }
        public string Feedback { get; set; }

        public static List<QuizQuestion> GetSampleQuestions()
        {
            return new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "What does 2FA stand for?",
                    Options = new List<string> { "Two-Factor Authentication", "Two-Face Authorization", "Two-Form Access", "Twice Fast Approval" },
                    Answer = "Two-Factor Authentication",
                    Feedback = "2FA means you need two forms of verification to log in, adding extra security."
                },
                new QuizQuestion
                {
                    Question = "Which of these is a strong password?",
                    Options = new List<string> { "password123", "MyBirthDate", "7h!sIs$tr0ng", "123456" },
                    Answer = "7h!sIs$tr0ng",
                    Feedback = "Strong passwords combine letters, numbers, and symbols."
                },
                new QuizQuestion
                {
                    Question = "What is phishing?",
                    Options = new List<string> { "Fishing in the ocean", "Fake emails to steal data", "Secure data encryption", "A cybersecurity protocol" },
                    Answer = "Fake emails to steal data",
                    Feedback = "Phishing involves tricking users into revealing sensitive info via fake emails or sites."
                },
                new QuizQuestion
                {
                    Question = "What does HTTPS stand for?",
                    Options = new List<string> { "HyperText Transfer Protocol Secure", "HyperText Transfer Protocol Simple", "Hyperlink Text Transfer Protection", "High Transfer Text Protocol" },
                    Answer = "HyperText Transfer Protocol Secure",
                    Feedback = "HTTPS encrypts communication over HTTP using SSL/TLS to protect data in transit."
                },
                new QuizQuestion
                {
                    Question = "Which of the following is a common sign of a phishing email?",
                    Options = new List<string> { "An unexpected attachment", "A secure padlock in the URL", "A request to update your operating system", "A large file download prompt" },
                    Answer = "An unexpected attachment",
                    Feedback = "Phishing emails often include unexpected attachments to deliver malware or extract information."
                },
                new QuizQuestion
                {
                    Question = "What is the principle of least privilege?",
                    Options = new List<string> { "Users have full admin rights by default", "Users receive the lowest level of access needed", "Users reuse the same password for convenience", "Users automatically get elevated permissions" },
                    Answer = "Users receive the lowest level of access needed",
                    Feedback = "Least privilege means giving users only the access necessary to perform their duties."
                },
                new QuizQuestion
                {
                    Question = "What is social engineering in cybersecurity?",
                    Options = new List<string> { "Physically breaking into a server room", "A software encryption method", "Psychological manipulation to gain trust", "A type of firewall technology" },
                    Answer = "Psychological manipulation to gain trust",
                    Feedback = "Social engineering relies on human interaction to trick individuals into giving up confidential information."
                },
                new QuizQuestion
                {
                    Question = "Which factor is NOT part of multi-factor authentication?",
                    Options = new List<string> { "Something you know (password)", "Something you have (token)", "Something you are (biometric)", "Your username" },
                    Answer = "Your username",
                    Feedback = "A username identifies you but is not an authentication factor."
                },
                new QuizQuestion
                {
                    Question = "What is a firewall?",
                    Options = new List<string> { "A device or software that filters network traffic", "A virus removal tool", "A coding framework", "A wireless router" },
                    Answer = "A device or software that filters network traffic",
                    Feedback = "Firewalls monitor and control incoming and outgoing network traffic based on security rules."
                },
                new QuizQuestion
                {
                    Question = "How often should you install security updates?",
                    Options = new List<string> { "Only when a critical vulnerability is announced", "Immediately after they become available", "Once a year", "Never" },
                    Answer = "Immediately after they become available",
                    Feedback = "Applying updates promptly ensures you are protected against known vulnerabilities."
                }
            };
        }
    }
}

/*
 * Title:        C# Tutorial – Create a simple multiple choice quiz game in Visual Studio
 * Author:       Moo ICT
 * Date:         n.d.
 * Availability: https://www.mooict.com/c-tutorial-create-a-simple-multiple-choice-quiz-game-in-visual-studio/
 */

